/* 
 * File:   main.cpp
 * Author: Fred Roybal IV
 * Created on June 29, 2015, 3:19 AM
 * Purpose: Homework. Output a message
 */

//System Libraries
#include <iostream> //FIle I/O
using namespace std;

//User Libraries

//Global constants

//Function prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables Here
    
    //Input Values Here
    
    //Process Input Here
    
    //Output Unknowns Here
    cout<<"*****************************************************************\n";
    cout<<"              C C C                   S S S S            !!  "<<endl;
    cout<<"             C      C                S       S           !!  "<<endl;
    cout<<"            C                       S                    !!  "<<endl;
    cout<<"           C                         S                   !!  "<<endl;
    cout<<"           C                          S S S S            !!  "<<endl;
    cout<<"            C                                 S          !!  "<<endl;
    cout<<"             C      C                S       S               "<<endl;
    cout<<"              C C C                   S S S S            00  "<<endl;
    cout<<"*****************************************************************\n";
    cout<<" "<<endl;
    cout<<" "<<endl;
    cout<<"                Computer Science is Cool Stuff!!!            "<<endl;
    
    //Exit Stage Right!
    
    return 0;
}

